$(document).ready(function() {

  $('#p2pSaveCard').on('hidden.bs.modal', function (event) {
    $('.p2p-save-card').find('.checkbox-input').prop('checked', false);
  })

})